# General helper functions used for mnist data analysis
asc <- function(x) { strtoi(charToRaw(x),16L) } # character to ascii code
asci <- function(n) { rawToChar(as.raw(n)) } # ascii code to charcater 

# Show one image with label
DisplayImage <- function(X, y, z_map, i)
{
  if(dim(z_map)[1]==10) # digits
  {
    I <- array_reshape((X[i,]), c(28, 28), order = "C")
    I <- t(I[c(28:1),])
  }
  else # transposed data 
  {
    I <- array_reshape((rev((X[i,]))), c(28, 28), order = "C")
    I <- I[c(28:1),]
  }
  image(I, # c("C", "F"))), 
        col = grey(seq(1, 0, length = 256)), 
        useRaster=TRUE, axes=FALSE, main= asci(z_map[y[i]+1,2]))
  return(0)
}

# Display random k images with wrong classification. 
# Can be useful when understanding classification errors 
DisplayErrorImages <- function(X, y, y_hat, z_mat, k) 
{
  if(k<0)
  {
    I <- which(y == y_hat)
    k <- abs(k)
  }
  else
  {
    I <- which(y != y_hat)
  }
  
  n <- length(I)
  I <- I[sample(c(1:n), k, replace = FALSE, prob = NULL)]
  k_row <- floor(sqrt(k))
  k_col <- ceiling(k / k_row)
  attach(mtcars)
  par(mfrow=c(k_row,k_col), mar=c(1,1,1,1))
  ctr <- 1 
  for(i in 1:k_row)
  {
    for(j in 1:k_col)
    {
      print(ctr)
      if(ctr <= k)
      {
        DisplayImage(X[I,], y_hat[I], z_map, ctr)
      }
      ctr <- ctr+1
    }
  }  
}



# Compute prediction accuracy
EvaluateModel <- function(y, y_hat)  
{
  accuracy <- mean(y == y_hat) # for hard classifiers
}  
  


# add random noise to image 
AddNoiseToImage <- function(X, p)
{
  X_noisy <- (X+matrix(rbinom(prod(dim(X)),1,p),dim(X)[1],dim(X)[2]))%%2
}

# Rotate image with random direction 
RotateImage <- function(X, rot)
{
  if(rot>1)
  {
    X_rotated <- RotateImage(RotateImage(X, rot-1), 1)
  }
  else
  {
    X_rotated <- X
    n <- dim(X)[1]
    for(i in 1:n) 
      for(j in 1:n) 
        X_rotated[i,j] <- X[j,n+1-i]
  }
  return(X_rotated)
} 
  
  


# Compute prediction error. We use 0/1 loss 
EvaluateModel <- function(y, y_hat)  
{
  accuracy <- mean((y) == (y_hat))
}  


# Show time and accuracy of classifiers   
PlotClassifiersResults <- function(time, accuracy, labels, output_file = NULL)
{
  while (!is.null(dev.list()))  dev.off()
  if(!is.null(output_file))
  {
    jpeg(output_file);
  }
  plot(time, accuracy, xlab='Run Time (sec.)', ylab="Accuracy (%)", log = "y", xlim=c(0, max(time)), ylim=c(min(accuracy)-1, 100))
  text(time, accuracy, labels=labels, cex= 0.7, pos=1)
  if(!is.null(output_file))
  {
    dev.off()
  }
}




# Show if probabilistic model predictions are calibrated 
CalibrationPlot <- function(y, y_prob_hat)
{
  lab <- sort(unique(y)) # get all labels 
  n_bins <- 50
  x_vec <- (c(1:n_bins)-0.5)/n_bins
  attach(mtcars)
  par(mfrow=c(2,5), mar=c(2,2,1,1))
  for (i in c(1:length(lab)))
  {
    accuracy_vec <- rep(0, n_bins); n_vec <- rep(0, n_bins)
    for(j in c(1:n_bins))
    {
      I <- which( (y_prob_hat[,i] >= (j-1)/n_bins) & (y_prob_hat[,i] < j/n_bins) )
      accuracy_vec[j] <- mean(y[I] == lab[i])
      n_vec[j] <- length(I)
    }
    J <- which(n_vec>10)
    print(J)
    plot(x_vec[J], accuracy_vec[J], main=lab[i], xlab='P-model', ylab='P-data')
    if(i>5)
    {
      mtext(text='P-model',side=1,cex=0.7)
    }
    if(is.element(i, c(5,10)))
    {
      mtext(text='P-data',side=4, cex=0.7)
    }
    lines(x_vec, x_vec) # plot expected line 
  }
}

# Show confusion matrix for pairs of labels 
ConfusionMatrix <- function(y, y_hat, prob_flag = FALSE)
{
  lab <- sort(unique(y)) # get all labels 
  n <- length(lab)
  M <- matrix(0, n, n)
  for(i in c(1:n))
  {
    for(j in c(1:n))
    {
      if(prob_flag)
      {
        M[i,j] <- sum(y_hat[which(y==lab[i]),j]) / length(y)
      }
      else
      {
        M[i,j] <- mean((y==lab[i]) & (y_hat==lab[j]))
      }
    }
  }
  
  image(M, 
        col = grey(seq(1, 0, length = 256)), 
        useRaster=TRUE, axes=FALSE, main= 'Confusion Matrix', 
        xlab='Correct', ylab='Predicted')  
  mtext(text=lab, side=2, line=0.3, at=seq(0,1,1/(n-1)), las=1, cex=0.8)
  mtext(text=lab, side=1, line=0.3, at=seq(0,1,1/(n-1)), las=1, cex=0.8)
  return(M)      
}




