ID <- c(999999999, 123456789) # students ID here 

# predict label for entire word in a text set using learned parameters and model 
# X - an image representing a word 
# m.image - a neural network model trained on images
# m.text - a text-statistics model trained on natural text 
# 
PredictModelWord <- function(X, m.image, m.text)
{
  p <- 28 # assumed image length 
  n_words <- dim(X)[1] / p # number of words 
  L <- dim(X)[2] / p # number of characters in word 
  k <- length(dim(m.text$freq)) # get number of dimensions       
  y_hat <- vector("list", length = n_words) # set vector for output predicted characters 
  
  for(i in 1:n_words) # loop on words and predict 
  {
    if(i%%100==0)
    {
      print(paste("Predict ", i))
    }
    y_hat_prob <- m.image %>% predict_proba(array_reshape(t(X[(i*p):((i-1)*p+1),]), c(L,p*p), order="C")) # get predicted probabilities for each letter     
    y_hat_numeric <- rep(-1, L) # Next, determine MAP letters in independence model  
    for(j in 1:L) 
    {
       y_hat_numeric[j] <- which.max(y_hat_prob[j,] * m.text$freq)  
    }   
    y_hat[i] <- asci(m.text$z_map[y_hat_numeric,2]) # convert to asci characters 
  }
  return(unlist(y_hat))
}

